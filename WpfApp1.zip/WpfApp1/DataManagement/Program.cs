﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1;


namespace DataManagement
{
    public class Program
    {
        static void Main(string[] args)
        {
            //create db model
            CustomerData db = new CustomerData("WpfApp1");
            
            using (db)
            {
                //create some bookings
                

                //create some customers
                Customer c1 = new Customer() { Name = "Tom Jones", ContactNumber = "086-123 4567", };
                Customer c2 = new Customer() { Name = "Mary Smith", ContactNumber = "086 546 3214" };
                Customer c3 = new Customer() { Name = "Jo Doyle", ContactNumber = "087 1221 222" };
                //add to db


                //save changes

                db.SaveChanges();

            }





        }
    }
}

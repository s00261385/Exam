﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        CustomerData db = new CustomerData("WpfApp1");
        public MainWindow()
        {
            InitializeComponent();
            datePicker.SelectedDateChanged += datePicker_SelectedDateChanged_1;
            LoadBookingsByDate(DateTime.Today);
            LoadCustomers();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {

            

            Window1 secondWindow = new Window1();
            secondWindow.Show();
        }

        
        private void LoadBookingsByDate(DateTime selectedDate)
        {
            
                //i don t understnd why it does display the name in the listbox 
                db.Bookings.Where(b => DbFunctions.TruncateTime(b.BookingsDate) == selectedDate.Date).Load();

                
                var bookings = db.Bookings.ToList();

                lbx.ItemsSource = bookings.Select(b => $"{b.Customer.Name} ({b.Customer.ContactNumber}) - Party of {b.NumberOfparticipants}");
                

                
                int bookingsCount = bookings.Count;
                txtBlockBoo.Text = $"Bookings: {bookingsCount}";

                int availableSpace = 40 - bookings.Sum(b => b.NumberOfparticipants);
                txtBlockAvai.Text = $"Available: {availableSpace}";
            
        }

        private void LoadCustomers()
        {
            
            var customers = db.Customer.ToList();
           
            lbx.ItemsSource = customers.Select(c => c.Name);
        }

        private void datePicker_SelectedDateChanged_1(object sender, SelectionChangedEventArgs e)
        {
            LoadBookingsByDate(datePicker.SelectedDate ?? DateTime.Today);
        }

        private void listBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }
    }
}
